package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.modal.Order;
import com.example.demo.repo.OrderRepo;






@Service
@Transactional
public class OrderService {

	final OrderRepo orderRepo;

	@Autowired
	public OrderService(OrderRepo orderRepo) {
		this.orderRepo = orderRepo;

	}

	public List<Order> getAllOrder() {
		List<Order> orders = new ArrayList<Order>();
		orderRepo.findAll().forEach(order1 -> {
			orders.add(order1);
		});
		
		return orders;
	}

	public Order getOrderById(int orderId) {
		return orderRepo.findById(orderId).get();
	}

	public void saveOrUpdate(Order order) {
		orderRepo.save(order);
	}

	public void delete(int orderId) {
		orderRepo.deleteById(orderId);
	}


}
