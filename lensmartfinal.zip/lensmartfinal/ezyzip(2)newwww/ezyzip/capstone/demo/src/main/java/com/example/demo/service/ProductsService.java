package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.modal.Products;
import com.example.demo.repo.ProductsRepository;






@Service
@Transactional
public class ProductsService {

	final ProductsRepository productsRepository;

	@Autowired
	public ProductsService(ProductsRepository productsRepository) {
		this.productsRepository = productsRepository;

	}

	public List<Products> getAllProducts() {
		List<Products> products = new ArrayList<Products>();
		productsRepository.findAll().forEach(product1 -> {
			products.add(product1);
		});
		
		return products;
	}

	public Products getProductsById(int product_id) {
		return productsRepository.findById(product_id).get();
	}

	public void saveOrUpdate(Products products) {
		productsRepository.save(products);
	}

	public void delete(int product_id) {
		productsRepository.deleteById(product_id);
	}



}